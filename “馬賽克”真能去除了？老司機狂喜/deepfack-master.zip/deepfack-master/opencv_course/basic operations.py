import cv2
import numpy as np

image = cv2.imread('red_panda.jpg')
rows, cols, ch = image.shape

roi = image [100: 280, 150: 320]


print(image[175, 300])
image[250, 180] = (255, 0, 0)

cv2.imshow('original', image)
cv2.imshow('roi', roi)
cv2.waitKey(0)
cv2.destroyAllWindows()