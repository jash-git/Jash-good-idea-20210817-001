import cv2

import numpy as np

img1 = cv2.imread('car.jpg')
img2 = cv2.imread('road.jpg')

sum = cv2.add(img1, img2)
weighted = cv2.addWeighted(img1, 0.7, img2, 0.3, 0)

cv2.imshow('img1', img1)
cv2.imshow('img2', img2)
cv2.imshow('sum', sum)
cv2.imshow('weighted', weighted)
cv2.waitKey(0)
cv2.destroyAllWindows()

