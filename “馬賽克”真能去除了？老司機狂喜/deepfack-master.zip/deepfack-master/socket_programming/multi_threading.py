# https://www.youtube.com/watch?v=PJ4t2U15ACo

# import time
# import threading
#
#
# def calc_square(numbers):
#     print('calculate square numbers:')
#     for n in numbers:
#         time.sleep(0.2)
#         print('square:', n * n)
#
#
# def calc_cube(numbers):
#     print('calculate cube of nubmers')
#     for n in numbers:
#         time.sleep(0.2)
#         print('cube:', n ** 3)
#
#
# arr = [2, 3, 8, 9]
#
# t = time.time()
# t1 = threading.Thread(target=calc_square, args=(arr, ))
# t2 = threading.Thread(target=calc_cube, args=(arr,))
# t1.start()
# t2.start()
#
# t1.join()
# t2.join()
# print('done in: ', time.time() - t)
# print('all jobs done')


# https://www.youtube.com/watch?v=6eqC1WTlIqc
#
# from threading import Thread
# import time
#
#
# def timer(name, delay, repeat):
#     print('Timber: ' + name + 'Started')
#     while repeat > 0:
#         time.sleep(delay)
#         print(name + ':' + str(time.ctime(time.time())))
#         repeat -= 1
#     print('Timer: ' + name  + ' completed')
#
#
# def main():
#     t1 = Thread(target=timer, args=("Timer 1", 1, 5))
#     t2 = Thread(target=timer, args=('Timer 2', 2, 5))
#
#     t1.start()
#     t2.start()
#
#     t1.join()
#     t2.join()
#     print('main completed')
#
# if __name__ == '__main__':
#     main()

# import threading
# import time
#
#
# class AsyncWrite(threading.Thread):
#     def __init__(self, text, out):
#         threading.Thread.__init__(self)
#         self.text = text
#         self.out = out
#
#     def run(self):
#         f = open(self.out, 'a')
#         f.write(self.text + '\n')
#         f.close()
#         time.sleep(2)
#         print('Background file writing Finished to ' + self.out)
#
# def main():
#     message = input('Enter a string to store:')
#     backgound = AsyncWrite(message, 'out.txt')
#     backgound.start()
#     print('the program can continue whlie it writes in another thread..')
#     print('1000 + 4000 =', 1000 + 4000)
#
#     backgound.join()
#     print('waited until backgroud threads ends')
#
#
# if __name__ == '__main__':
#     main()


# import threading
# import time
#
# tLock = threading.Lock()
#
# def timer(name, delay, repeat):
#     print('Timber: ' + name + 'Started')
#     tLock.acquire()
#     print(name + "has acquired the lock.")
#     while repeat > 0:
#         time.sleep(delay)
#         print(name + ':' + str(time.ctime(time.time())))
#         repeat -= 1
#     print(name + 'is releasing the lock')
#     tLock.release()
#     print('Timer: ' + name  + ' completed')
#
#
# def main():
#     t1 = threading.Thread(target=timer, args=("Timer 1", 1, 5))
#     t2 = threading.Thread(target=timer, args=('Timer 2', 2, 5))
#
#     t1.start()
#     t2.start()
#
#     t1.join()
#     t2.join()
#     print('main completed')
#
# if __name__ == '__main__':
#     main()