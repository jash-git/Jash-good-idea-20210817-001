import socket


s = socket.socket()

port = 12345

s.connect(('144.202.93.164', port))

print(s.recv(1024).decode())
s.close()


