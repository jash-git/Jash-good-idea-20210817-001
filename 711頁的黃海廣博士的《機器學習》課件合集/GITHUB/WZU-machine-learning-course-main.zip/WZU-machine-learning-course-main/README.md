
# 机器学习课程-温州大学

本学期我给研究生上机器学习课程，我把课件分享下，后续陆续更新。

课程登陆了中国大学慕课平台，预计9月开课。

课程地址：https://www.icourse163.org/course/WZU-1464096179?tid=1464959450

如果有老师需要ppt原版文件，请联系我：haiguang2000@wzu.edu.cn

（邮件较多，请告知姓名、学校，我都会回复。）

黄海广

## 目录说明

ppt：课程的课件

code：课程的代码（Jupyter notebook格式）

video：课程的视频



PPT的百度云地址（链接：https://pan.baidu.com/s/1AW7P8dZfGMBgveBygmJlqg ，提取码：6r80 ）

内容首发于微信公众号：机器学习初学者 ![gongzhong](images/gongzhong.jpg)
