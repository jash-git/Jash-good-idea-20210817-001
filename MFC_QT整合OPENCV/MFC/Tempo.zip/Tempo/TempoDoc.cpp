
// TempoDoc.cpp : implementation of the CTempoDoc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "Tempo.h"
#endif

#include "TempoDoc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CTempoDoc

IMPLEMENT_DYNCREATE(CTempoDoc, CDocument)

BEGIN_MESSAGE_MAP(CTempoDoc, CDocument)
END_MESSAGE_MAP()

// CTempoDoc construction/destruction

CTempoDoc::CTempoDoc()
	:m_bErase(FALSE)
	,m_pBmi(NULL)
{
	// TODO: add one-time construction code here

}

CTempoDoc::~CTempoDoc()
{
	if(NULL != m_pBmi)
		delete m_pBmi;
}

BOOL CTempoDoc::OnNewDocument()
{
	if (! CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

// CTempoDoc serialization

void CTempoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CTempoDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CTempoDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CTempoDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CTempoDoc diagnostics

void CTempoDoc::ResizeMat(cv::Mat& mat)
{
	int nPadding = 0;
	if (CV_8UC4 != mat.type()) // padding is not needed for 32bit images
	{
		nPadding = 4 - (mat.cols % 4);
		if(4 == nPadding)
			nPadding = 0;
	}

	cv::Mat matTemp;
	if(nPadding > 0 || ! mat.isContinuous())
	{
		// Adding needed columns on the right (max 3 px)
		cv::copyMakeBorder(mat, matTemp, 0, 0, 0, nPadding, cv::BORDER_REPLICATE, 0);
		mat = matTemp;
	}
}

void CTempoDoc::SetupBitmapInfo(cv::Mat& mat)
{
	if(NULL != m_pBmi)
	{
		delete m_pBmi;
		m_pBmi = NULL;
	}
	m_pBmi = new BITMAPINFO;
	BITMAPINFOHEADER* pHeader = &m_pBmi->bmiHeader;
	pHeader->biSize				= sizeof(BITMAPINFOHEADER);
	pHeader->biPlanes			= 1;
	pHeader->biCompression		= BI_RGB;
	pHeader->biXPelsPerMeter	= 100;
	pHeader->biYPelsPerMeter	= 100;
	pHeader->biClrUsed			= 0;
	pHeader->biClrImportant		= 0;
	pHeader->biWidth			= m_Mat.cols;
	pHeader->biHeight			= -m_Mat.rows;
	pHeader->biBitCount			= 24;
	m_pBmi->bmiHeader.biSizeImage = 0;
}

#ifdef _DEBUG
void CTempoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTempoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

// CTempoDoc commands

BOOL CTempoDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (! CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// TODO: Add your specialized creation code here

	CString sTemp;
	sTemp.LoadString(AFX_IDS_IDLEMESSAGE);
	::SendMessage(theApp.m_pMainWnd->GetSafeHwnd(), WM_SETMESSAGESTRING, 0, (LPARAM)(LPCTSTR)sTemp);

	m_bErase = TRUE;
	CView* pView = NULL;
	POSITION pos = GetFirstViewPosition();
	while(NULL != pos)
	{
		pView = GetNextView(pos);
		break;
	}

	if(! m_Video.open(lpszPathName) || NULL == pView)
		return FALSE;

	if(m_Video.get(CV_CAP_PROP_FRAME_COUNT) < 2)    // is image, not video
	{
		::PostMessage(pView->GetSafeHwnd(), WMU_SETFPS, 0, 0);
		m_Mat.release();
		m_Mat = cv::imread(lpszPathName);
		ResizeMat(m_Mat);
		SetupBitmapInfo(m_Mat);
		return TRUE;
	}

	double dFPS = m_Video.get(CV_CAP_PROP_FPS);
	m_Video.read(m_Mat);
	SetupBitmapInfo(m_Mat);
	::PostMessage(pView->GetSafeHwnd(), WMU_SETFPS, 1000 / (int)dFPS, 0);

	return TRUE;
}

void CTempoDoc::ShowNextFrame()
{
	if(m_Video.isOpened())
	{
		m_Video.read(m_Mat);
	}

	int nIndex = static_cast<int>(m_Video.get(CV_CAP_PROP_POS_FRAMES));
	int nTotal = static_cast<int>(m_Video.get(CV_CAP_PROP_FRAME_COUNT));

	if(nIndex >= nTotal)
	{
		CView* pView = NULL;
		POSITION pos = GetFirstViewPosition();
		while(NULL != pos)
		{
			pView = GetNextView(pos);
			::PostMessage(pView->GetSafeHwnd(), WMU_SETFPS, 0, 0);
		}
	}
}
